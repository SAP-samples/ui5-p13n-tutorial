import Controller from "sap/ui/core/mvc/Controller"

/**
 * @namespace sample.p13n.app.controller
 */
export default class MountainsController extends Controller {
	public  onInit(): void {
	}
}
